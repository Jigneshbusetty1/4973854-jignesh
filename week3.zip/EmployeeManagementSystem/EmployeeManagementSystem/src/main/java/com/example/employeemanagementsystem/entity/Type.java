package com.example.employeemanagementsystem.entity;

public @interface Type {

	String type();
}
