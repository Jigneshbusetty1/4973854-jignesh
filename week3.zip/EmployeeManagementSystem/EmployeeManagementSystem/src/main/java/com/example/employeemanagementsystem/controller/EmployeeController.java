package com.example.employeemanagementsystem.controller;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.employeemanagementsystem.repository.EmployeeRepository;
import com.example.employeenameprojection.EmployeeDetails;
import com.example.employeenameprojection.EmployeeNameProjection;

import java.util.List;

@RestController
@RequestMapping("/employees")
public class EmployeeController {

    @Autowired
    private EmployeeRepository employeeRepository;

    @GetMapping("/names")
    public List<EmployeeNameProjection> getEmployeeNames() {
        return employeeRepository.findEmployeeNames();
    }

    @GetMapping("/details")
    public List<EmployeeDetails> getEmployeeDetails() {
        return employeeRepository.findEmployeeDetails();
    }
}



