package com.example.employeemanagementsystem.repository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
//import org.springframework.data.repository.query.Param;

import com.example.employeemanagementsystem.entity.Employee;
import com.example.employeenameprojection.EmployeeDetails;
import com.example.employeenameprojection.EmployeeNameProjection;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    @Query("SELECT e.name as name, e.email as email, d.name as departmentName FROM Employee e JOIN e.department d")
    List<EmployeeNameProjection> findEmployeeNames();

    @Query("SELECT new com.example.projection.EmployeeDetails(e.name, e.email, d.name) FROM Employee e JOIN e.department d")
    List<EmployeeDetails> findEmployeeDetails();

	Page<Employee> findByDepartmentName(String departmentName, Pageable pageable);
}

