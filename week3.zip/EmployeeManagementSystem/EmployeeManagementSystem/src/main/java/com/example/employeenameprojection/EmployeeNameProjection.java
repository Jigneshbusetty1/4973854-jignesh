package com.example.employeenameprojection;
public interface EmployeeNameProjection {
    String getName();
    String getEmail();
    String getDepartmentName();

    interface DepartmentInfo {
        String getName();
    }

    DepartmentInfo getDepartment();
}
