package com.example.employeenameprojection;
public class EmployeeDetails {
    private String name;
    private String email;
    private String departmentName;

    public EmployeeDetails(String name, String email, String departmentName) {
        this.setName(name);
        this.setEmail(email);
        this.setDepartmentName(departmentName);
    }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDepartmentName() {
		return departmentName;
	}

	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}

}

