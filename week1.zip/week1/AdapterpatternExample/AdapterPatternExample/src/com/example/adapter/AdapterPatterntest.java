package com.example.adapter;

public class AdapterPatterntest {
	public static void main(String[] args)
	{
		    Paypal payPal = new Paypal();
	        Paymentprocessor payPalProcessor = new PayPaladapter(payPal);
	        payPalProcessor.processPayment(100);

	        Stripe stripe = new Stripe();
	        Paymentprocessor stripeProcessor = new Stripeadapter(stripe);
	        stripeProcessor.processPayment(200);

	        Square square = new Square();
	        Paymentprocessor squareProcessor = new Squareadapter(square);
	        squareProcessor.processPayment(300); 
	}
}
