package com.example.adapter;

public class Stripe {
	public void sendPayment(double amount) {
		System.out.println("processing payment of $" + amount + " By Stripe");
		}
}
