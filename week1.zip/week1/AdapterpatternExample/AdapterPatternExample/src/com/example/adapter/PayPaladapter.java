package com.example.adapter;

public class PayPaladapter implements Paymentprocessor {

    private Paypal payPal;

    public PayPaladapter(Paypal Paypal) {
        this.payPal = Paypal;
    }

    @Override
    public void processPayment(double amount) {
        payPal.makePayment(amount);
    }
}
