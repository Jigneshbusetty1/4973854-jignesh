package com.example.adapter;

public class Square {
	public void processTransaction(double amount) {
        System.out.println("processing payment of $" + amount + " By Square");
    }
}
