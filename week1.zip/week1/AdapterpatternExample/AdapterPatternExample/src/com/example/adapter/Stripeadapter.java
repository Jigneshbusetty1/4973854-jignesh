package com.example.adapter;

public class Stripeadapter implements Paymentprocessor{
	private Stripe stripe;
	public Stripeadapter(Stripe stripe)
	{
		this.stripe = stripe;
	}
	@Override
	public void processPayment(double amount)
	{
		stripe.sendPayment(amount);
	}

}

