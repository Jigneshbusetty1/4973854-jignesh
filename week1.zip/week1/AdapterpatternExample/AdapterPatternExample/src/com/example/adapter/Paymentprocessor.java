package com.example.adapter;

public interface Paymentprocessor {
	void processPayment(double amount);
}
