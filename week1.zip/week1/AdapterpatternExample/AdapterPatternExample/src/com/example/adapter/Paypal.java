package com.example.adapter;

public class Paypal {
	public void makePayment(double amount) {
        System.out.println("processing payment of $" + amount + " By Paypal");
    }
}
