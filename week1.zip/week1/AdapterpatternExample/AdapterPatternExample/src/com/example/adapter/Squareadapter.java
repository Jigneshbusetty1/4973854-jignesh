package com.example.adapter;

public class Squareadapter implements Paymentprocessor{
	private Square square;
	public Squareadapter(Square square)
	{
		this.square = square;
	}
	@Override
	public void processPayment(double amount)
	{
		square.processTransaction(amount);
	}
}
