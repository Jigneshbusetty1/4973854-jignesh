package com.example.mvc;

public class MVCPatterntest {
	public static void main(String[] args) {
        Student student = new Student("1", "preethi", "A");
        Studentview view = new Studentview();
        Studentcontroller controller = new Studentcontroller(student, view);
        controller.updateView();
        controller.setStudentName("Maggy");
        controller.setStudentGrade("B");
        controller.updateView();
    }
}
