package com.example.magagment;

class Employee {
    private int employeeId;
    private String name;
    private String position;
    private double salary;

    public Employee(int employeeId, String name, String position, double salary) {
        this.employeeId = employeeId;
        this.name = name;
        this.position = position;
        this.salary = salary;
    }

    public int getEmployeeId() {
        return employeeId;
    }

    public String getName() {
        return name;
    }

    public String getPosition() {
        return position;
    }

    public double getSalary() {
        return salary;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "employeeId=" + employeeId +
                ", name='" + name + '\'' +
                ", position='" + position + '\'' +
                ", salary=" + salary +
                '}';
    }
}
class employeeManagementSystem {
    private Employee[] employees;
    private int count;

    public employeeManagementSystem(int size) {
        employees = new Employee[size];
        count = 0;
    }

    public void addEmployee(Employee employee) {
        if (count < employees.length) {
            employees[count] = employee;
            count++;
        } else {
            System.out.println("Array is full. Cannot add more employees.");
        }
    }
    public Employee searchEmployee(int employeeId) {
        for (int i = 0; i < count; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                return employees[i];
            }
        }
        return null;
    }
    public void displayEmployees() {
        for (int i = 0; i < count; i++) {
            System.out.println(employees[i]);
        }
    }
    public void deleteEmployee(int employeeId) {
        for (int i = 0; i < count; i++) {
            if (employees[i].getEmployeeId() == employeeId) {
                for (int j = i; j < count - 1; j++) {
                    employees[j] = employees[j + 1];
                }
                employees[count - 1] = null;
                count--;
                return;
            }
        }
        System.out.println("Employee not found.");
    }
}
public class Employee_Management_system {
    public static void main(String[] args) {
        employeeManagementSystem ems = new employeeManagementSystem(5);
        // Adding
        ems.addEmployee(new Employee(1, "Ram", "Developer", 60000));
        ems.addEmployee(new Employee(2, "Charan", "Manager", 80000));
        ems.addEmployee(new Employee(3, "Ntr", "Designer", 55000));
        // Display
        System.out.println("All Employees:");
        ems.displayEmployees();
        // Search
        System.out.println("\nSearching for Employee with ID 2:");
        Employee employee = ems.searchEmployee(2);
        if (employee != null) {
            System.out.println("Found: " + employee);
        } else {
            System.out.println("Employee not found.");
        }
        // Delete
        System.out.println("\nDeleting Employee with ID 1:");
        ems.deleteEmployee(1);
        ems.displayEmployees();
    }
}
