package com.example.magagment;

public class Financial_Forecasting {
	// Recursive method
    public double predictFutureValue(double currentValue, double growthRate, int periods) {
        // Base case: if no more periods, return the current value
        if (periods == 0) {
            return currentValue;
        }
        return predictFutureValue(currentValue * (1 + growthRate), growthRate, periods - 1);
    }

    // Iterative method
    public double predictFutureValueIterative(double currentValue, double growthRate, int periods) {
        double futureValue = currentValue;

        for (int i = 0; i < periods; i++) {
            futureValue *= (1 + growthRate);
        }

        return futureValue;
    }

    public static void main(String[] args) {
    	Financial_Forecasting tool = new Financial_Forecasting();

        double currentValue = 1000.0; // Current value
        double growthRate = 0.05; // 5% growth rate
        int periods = 10; // Number of periods to forecast

        //recursive
        double futureValueRecursive = tool.predictFutureValue(currentValue, growthRate, periods);
        System.out.println("Predicted Future Value after " + periods + " periods (Recursive): $" + futureValueRecursive);

        //iterative
        double futureValueIterative = tool.predictFutureValueIterative(currentValue, growthRate, periods);
        System.out.println("Predicted Future Value after " + periods + " periods (Iterative): $" + futureValueIterative);
    }
}
