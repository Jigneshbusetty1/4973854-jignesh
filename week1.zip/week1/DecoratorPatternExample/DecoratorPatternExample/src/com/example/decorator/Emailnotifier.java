package com.example.decorator;

public class Emailnotifier implements Notifier{
	@Override
	public void send(String message)
	{
		System.out.println("sending email notification : " + message);
	}

}
