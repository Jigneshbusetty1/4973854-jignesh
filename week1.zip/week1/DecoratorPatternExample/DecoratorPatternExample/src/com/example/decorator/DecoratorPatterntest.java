package com.example.decorator;

public class DecoratorPatterntest {
	public static void main(String[] args) {
        // Basic Email notification
        Notifier emailNotifier = new Emailnotifier();
        emailNotifier.send("Hello, this is an email notification.");

        System.out.println();

        // Email + SMS notification
        Notifier emailAndSMSNotifier = new SMSNotifierdecorator(new Emailnotifier());
        emailAndSMSNotifier.send("Hello, this is an email and SMS notification.");

        System.out.println();

        // Email + SMS + Slack notification
        Notifier emailSMSAndSlackNotifier = new SlackNotifierdecorator(
                new SMSNotifierdecorator(new Emailnotifier())
        );
        emailSMSAndSlackNotifier.send("Hello, this is an email, SMS, and Slack notification.");
    }
}
