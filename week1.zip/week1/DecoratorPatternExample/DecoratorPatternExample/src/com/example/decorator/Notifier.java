package com.example.decorator;
public interface Notifier
{
	void send(String message);
}