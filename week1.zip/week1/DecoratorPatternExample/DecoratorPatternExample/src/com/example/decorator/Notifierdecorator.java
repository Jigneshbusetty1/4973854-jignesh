package com.example.decorator;

public abstract class Notifierdecorator implements Notifier{
	protected Notifier wrappedNotifier;
	public Notifierdecorator(Notifier notifier)
	{
		this.wrappedNotifier = notifier;
	}
	@Override
	public void send(String message)
	{
		wrappedNotifier.send(message);
		
	}
}
