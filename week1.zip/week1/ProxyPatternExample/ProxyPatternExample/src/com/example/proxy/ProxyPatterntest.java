package com.example.proxy;

public class ProxyPatterntest {
    public static void main(String[] args) {
        
        Image image1 = new Proxyimage("photo1.jpg");
        Image image2 = new Proxyimage("photo2.jpg");
        
        System.out.println("Displaying image1 for the first time:");
        image1.display();
        System.out.println("\nDisplaying image2 for the first time:");
        image2.display();
        System.out.println("\nDisplaying image1 again (should be from cache):");
        image1.display();
    }
}
