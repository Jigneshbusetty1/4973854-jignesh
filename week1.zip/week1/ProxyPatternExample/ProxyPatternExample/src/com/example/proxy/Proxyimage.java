package com.example.proxy;

public class Proxyimage implements Image{
	private String fileName;
    private Realimage realImage;

    public Proxyimage(String fileName) {
        this.fileName = fileName;
    }

    @Override
    public void display() {
        if (realImage == null) {
            realImage = new Realimage(fileName);
        }
        realImage.display();
    }

}
