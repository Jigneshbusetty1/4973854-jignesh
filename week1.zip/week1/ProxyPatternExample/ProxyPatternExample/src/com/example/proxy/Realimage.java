package com.example.proxy;

public class Realimage implements Image{
	    private String fileName;

	    public Realimage(String fileName) {
	        this.fileName = fileName;
	        loadImageFromServer();
	    }

	    private void loadImageFromServer() {
	        System.out.println("loading image from server: " + fileName);
	        try {
	            Thread.sleep(2000);
	        } catch (InterruptedException e) {
	            e.printStackTrace();
	        }
	    }

	    @Override
	    public void display() {
	        System.out.println("Displaying image: " + fileName);
	    }

}
