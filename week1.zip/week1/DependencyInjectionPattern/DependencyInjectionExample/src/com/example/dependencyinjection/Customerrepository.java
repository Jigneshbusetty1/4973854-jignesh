package com.example.dependencyinjection;

public interface Customerrepository {
	Customer findCustomerById(int id);
	
}
