package com.example.dependencyinjection;

public class Customersservice {
	 private final Customerrepository customerRepository;
	    public Customersservice(Customerrepository customerRepository) {
	        this.customerRepository = customerRepository;
	    }

	    public Customer getCustomerById(int id) {
	        return customerRepository.findCustomerById(id);
	    }
}
