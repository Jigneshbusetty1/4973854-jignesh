package com.example.dependencyinjection;

public class DependencyInjectiontest {
	public static void main(String[] args) {
        Customerrepository customerRepository = new CustomerRepositoryimpl();
        Customersservice customerService = new Customersservice(customerRepository);

        // Fetching a customer by ID
        Customer customer = customerService.getCustomerById(1);

        // Displaying the customer details
        System.out.println("Customer ID: " + customer.getId());
        System.out.println("Customer Name: " + customer.getName());
    }
}
