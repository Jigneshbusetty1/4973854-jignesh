package com.example.dependencyinjection;

public class CustomerRepositoryimpl implements Customerrepository{
	@Override
    public Customer findCustomerById(int id) {
        return new Customer(id, "Jignesh");
    }

}
