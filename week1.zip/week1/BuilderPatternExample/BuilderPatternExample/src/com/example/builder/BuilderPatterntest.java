package com.example.builder;

public class BuilderPatterntest {
	public static void main(String[] args) {
        computer basicComputer = new computer.ComputerBuilder()
                .setCPU("Intel i3")
                .setRAM("8GB")
                .setStorage("256GB SSD")
                .build();

        System.out.println("Basic Computer Configuration:");
        System.out.println(basicComputer);

        computer gamingComputer = new computer.ComputerBuilder()
                .setCPU("Intel i9")
                .setRAM("32GB")
                .setStorage("1TB SSD")
                .setGraphicsCard("NVIDIA RTX 3080")
                .setPowerSupply("750W")
                .setMotherboard("Asus ROG")
                .build();

        System.out.println("\nGaming Computer Configuration:");
        System.out.println(gamingComputer);
    }
}

