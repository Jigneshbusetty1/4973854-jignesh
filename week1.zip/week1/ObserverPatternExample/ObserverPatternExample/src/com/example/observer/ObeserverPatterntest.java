package com.example.observer;

public class ObeserverPatterntest {
	public static void main(String[] args) {
        Stockmarket stockMarket = new Stockmarket();

        Observer mobileApp1 = new Mobileapp("MobileApp1");
        Observer webApp1 = new Webapp("WebApp1");
        Observer mobileApp2 = new Mobileapp("MobileApp2");

        stockMarket.registerObserver(mobileApp1);
        stockMarket.registerObserver(webApp1);
        stockMarket.registerObserver(mobileApp2);
        
        System.out.println("Setting stock price to $100.00");
        stockMarket.setStockPrice(100.00);

        System.out.println("\nDeregistering MobileApp2 and setting stock price to $120.00");
        stockMarket.deregisterObserver(mobileApp2);
        stockMarket.setStockPrice(120.00);
    }
}
