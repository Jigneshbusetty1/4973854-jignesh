package com.example.observer;

public class ObserverPatternExample {

}
