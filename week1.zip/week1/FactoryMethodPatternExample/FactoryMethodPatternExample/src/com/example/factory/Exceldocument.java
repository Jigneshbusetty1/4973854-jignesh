package com.example.factory;

public class Exceldocument implements document{
	@Override
	public void open()
	{
		System.out.println("Opening excel document..");
	}
	@Override
	public void save()
	{
		System.out.println("Saveing excel document..");
	}
	@Override
	public void close()
	{
		System.out.println("Closing excel document..");
	}

}
