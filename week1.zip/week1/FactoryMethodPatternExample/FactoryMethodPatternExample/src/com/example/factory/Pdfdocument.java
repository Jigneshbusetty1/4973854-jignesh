package com.example.factory;

public class Pdfdocument implements document{
	@Override
	public void open()
	{
		System.out.println("Opening pdf document..");
	}
	@Override
	public void save()
	{
		System.out.println("Saving pdf document..");
	}
	@Override
	public void close()
	{
		System.out.println("Closing pdf document..");
	}

}
