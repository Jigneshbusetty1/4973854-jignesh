package com.example.factory;

public interface document {
	void open();
	void save();
	void close();
}
