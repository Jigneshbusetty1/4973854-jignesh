package com.example.factory;

public abstract class Documentfactory {
	public abstract document createDocument();

}
