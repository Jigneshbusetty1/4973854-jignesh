package com.example.factory;

public class FactoryMethodtest {
	public static void main(String[] args)
	{
		Documentfactory wordfactory = new WordDocumentfactory();
		document wordDoc = wordfactory.createDocument();
		wordDoc.open();
		wordDoc.save();
		wordDoc.close();
		
		Documentfactory pdffactory = new PdfDocumentfactory();
		document pdfDoc = pdffactory.createDocument();
		pdfDoc.open();
		pdfDoc.save();
		pdfDoc.close();
		
		Documentfactory excelfactory = new ExcelDocumentfactory();
		document excelDoc = excelfactory.createDocument();
		excelDoc.open();
		excelDoc.save();
		excelDoc.close();
	}

}
