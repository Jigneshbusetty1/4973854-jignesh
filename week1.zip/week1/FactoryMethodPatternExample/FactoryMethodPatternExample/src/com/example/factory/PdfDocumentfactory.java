package com.example.factory;

public class PdfDocumentfactory extends Documentfactory{
	@Override
	public document createDocument()
	{
		return new Pdfdocument();
	}

}
