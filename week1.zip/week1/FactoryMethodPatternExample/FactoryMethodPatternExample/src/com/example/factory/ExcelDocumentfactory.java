package com.example.factory;

public class ExcelDocumentfactory extends Documentfactory{
	@Override
	public document createDocument()
	{
		return new Exceldocument();
	}

}
