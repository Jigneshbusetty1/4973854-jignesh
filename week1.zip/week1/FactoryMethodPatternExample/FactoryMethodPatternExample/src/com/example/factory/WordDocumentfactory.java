package com.example.factory;

public class WordDocumentfactory extends Documentfactory{
	@Override
	public document createDocument()
	{
		return new Worddocument();
	}

}
