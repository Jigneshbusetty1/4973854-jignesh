package com.example.strategy;

public class Paymentcontext {
	private Paymentstrategy paymentStrategy;

    public void setPaymentStrategy(Paymentstrategy paymentStrategy) {
        this.paymentStrategy = paymentStrategy;
    }

    public void payAmount(double amount) {
        if (paymentStrategy == null) {
            System.out.println("No payment strategy selected.");
        } else {
            paymentStrategy.pay(amount);
        }
    }
}
