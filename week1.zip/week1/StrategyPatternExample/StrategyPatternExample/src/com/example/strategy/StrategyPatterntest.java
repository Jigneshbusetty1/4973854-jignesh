package com.example.strategy;

public class StrategyPatterntest {
	public static void main(String[] args) {
        Paymentcontext paymentContext = new Paymentcontext();
        Paymentstrategy creditCardPayment = new CreditCardpayment("9392-8837-5724-2002", "Andravathi", "123", "12/25");
        paymentContext.setPaymentStrategy(creditCardPayment);
        paymentContext.payAmount(250.00);
        Paymentstrategy payPalPayment = new PayPalpayment("andru@example.com", "password123");
        paymentContext.setPaymentStrategy(payPalPayment);
        paymentContext.payAmount(150.00);
    }
}
