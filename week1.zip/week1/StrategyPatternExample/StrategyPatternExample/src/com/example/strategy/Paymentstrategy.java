package com.example.strategy;

public interface Paymentstrategy {
	void pay(double amount);
}
