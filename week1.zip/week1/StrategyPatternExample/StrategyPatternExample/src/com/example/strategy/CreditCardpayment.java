package com.example.strategy;

public class CreditCardpayment implements Paymentstrategy{
	private String cardNumber;
    private String cardHolderName;
    public CreditCardpayment(String cardNumber, String cardHolderName, String cvv, String expirationDate) {
        this.cardNumber = cardNumber;
        this.cardHolderName = cardHolderName;
    }

    @Override
    public void pay(double amount) {
        System.out.println("Paid $" + amount + " using credit card.");
        System.out.println("Card Details: " + cardHolderName + " (" + cardNumber + ")");
    }
}
