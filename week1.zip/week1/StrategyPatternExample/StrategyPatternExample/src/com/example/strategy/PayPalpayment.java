package com.example.strategy;

public class PayPalpayment implements Paymentstrategy{
	private String email;
    private String password;

    public PayPalpayment(String email, String password) {
        this.email = email;
        this.password = password;
    }

    @Override
    public void pay(double amount) {
        System.out.println("Paid $" + amount + " using PayPal.");
        System.out.println("PayPal Account: " + email);
    }

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	

}
