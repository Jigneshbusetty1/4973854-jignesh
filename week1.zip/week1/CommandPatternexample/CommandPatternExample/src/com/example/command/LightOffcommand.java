package com.example.command;

public class LightOffcommand implements Command{
	private Light light;

    public LightOffcommand(Light light) {
        this.light = light;
    }

    @Override
    public void execute() {
        light.turnOff();
    }
}
