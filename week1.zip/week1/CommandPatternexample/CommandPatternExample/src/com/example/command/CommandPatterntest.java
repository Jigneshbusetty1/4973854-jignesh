package com.example.command;

public class CommandPatterntest {
	public static void main(String[] args) {
        Light livingRoomLight = new Light("Living Room");
        Light kitchenLight = new Light("Kitchen");

        Command livingRoomLightOn = new LightOncommand(livingRoomLight);
        Command livingRoomLightOff = new LightOffcommand(livingRoomLight);
        Command kitchenLightOn = new LightOncommand(kitchenLight);
        Command kitchenLightOff = new LightOffcommand(kitchenLight);

        Remotecontrol remote = new Remotecontrol();

        remote.setCommand(livingRoomLightOn);
        remote.pressButton();

        remote.setCommand(livingRoomLightOff);
        remote.pressButton();

        remote.setCommand(kitchenLightOn);
        remote.pressButton();

        remote.setCommand(kitchenLightOff);
        remote.pressButton();
    }
}
